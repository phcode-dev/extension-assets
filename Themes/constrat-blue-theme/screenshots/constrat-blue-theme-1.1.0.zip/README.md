Contrast Blue Theme for Brackets
=========

###### Python
![preview](preview/python.png)
###### Java
![preview](preview/php.png)
###### Bash
![preview](preview/java.png)
###### Sh
![preview](preview/bash.png)
###### Latex
![preview](preview/latex.png)
###### Html
![preview](preview/html.png)
###### Javasript
![preview](preview/javascript.png)
###### Css
![preview](preview/css.png)

For more themes and install instructions see the [Brackets Themes website](http://brackets-themes.github.io/)
