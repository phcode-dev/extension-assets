public enum SimpleSingleton {
	INSTANCE;
	public void doSomething() {
	}
}

//Call the method from Singleton:
SimpleSingleton.INSTANCE.doSomething();
